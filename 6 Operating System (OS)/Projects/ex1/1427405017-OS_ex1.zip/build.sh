#!/bin/bash
gcc game_judge.c -o judge
gcc game_player1.c -o player1
gcc game_player2.c -o player2
echo 'ex2 C程序编译完成'
