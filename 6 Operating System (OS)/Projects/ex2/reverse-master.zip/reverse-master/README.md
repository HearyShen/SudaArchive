A simple Linux kernel module developed as tutorial code.
