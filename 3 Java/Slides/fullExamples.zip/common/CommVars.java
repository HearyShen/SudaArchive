package common;

public class CommVars {
	public final static String DTP_PROJECT=System.getProperty("user.dir")+"/";
}
