package part1;

public class GUIFirst {
	
	public static void main(String[] args){
		
	}

}
