package tmp;

import java.util.*;

public class test {
	public static void main(String[] arg)
	{
		LinkedHashSet<String> hs = new LinkedHashSet<String>();
		hs.add("B");
		hs.add("A");
		hs.add("D");
		hs.add("E");
		hs.add("C");
		hs.add("F");
		System.out.println("HashSet ˳��:\n"+hs);
	}
}