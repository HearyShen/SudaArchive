package ch5;

public class exam05 {
	public static void main(String[] arg){
		String strb="false";
		boolean s=Boolean.getBoolean(strb);
		if (s)
			System.out.println("true");
		else
			System.out.println("false");
	}
}
